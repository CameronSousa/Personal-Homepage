const api = globalThis.browser ?? globalThis.chrome;

// URLs browsers use for their built-in "new tab" page
const NEW_TAB_PATTERNS = [
  /^chrome:\/\/newtab\/?$/,
  /^chrome:\/\/new-tab-page/,
  /^brave:\/\/newtab\/?$/,
  /^about:newtab\/?$/,
  /^chrome-search:\/\/local-ntp/,
  /^favorites:\/\//            // Safari's start page
];

const isNewTab = (url) => NEW_TAB_PATTERNS.some((re) => re.test(url || ""));

api.tabs.onCreated.addListener(async (tab) => {
  const url = tab.pendingUrl || tab.url || "";
  if (!isNewTab(url)) return;

  const { homepage } = await api.storage.sync.get("homepage");
  if (!homepage || isNewTab(homepage)) return; // nothing configured yet

  // Open the homepage as a normal tab (no address bar focus), then drop the blank one
  await api.tabs.create({
    url: homepage,
    index: tab.index + 1,
    windowId: tab.windowId,
    active: true
  });
  await api.tabs.remove(tab.id);
});
