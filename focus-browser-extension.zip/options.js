const api = globalThis.browser ?? globalThis.chrome;
const input = document.getElementById("url");
const status = document.getElementById("status");

api.storage.sync.get("homepage").then(({ homepage }) => {
  if (homepage) input.value = homepage;
});

document.getElementById("save").addEventListener("click", async () => {
  await api.storage.sync.set({ homepage: input.value.trim() });
  status.textContent = "Saved ✓";
  setTimeout(() => (status.textContent = ""), 1500);
});
